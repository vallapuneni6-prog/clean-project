<?php
// Test database connection
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Parse .env file
if (file_exists('.env')) {
    $lines = file('.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            list($key, $value) = explode('=', $line, 2);
            putenv(trim($key) . '=' . trim($value));
        }
    }
}

// Get database configuration
$db_host = getenv('DB_HOST') ?: 'localhost';
$db_name = getenv('DB_NAME') ?: 'ansira_db';
$db_user = getenv('DB_USER') ?: 'root';
$db_pass = getenv('DB_PASSWORD') ?: '';
$db_port = getenv('DB_PORT') ?: '3306';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Database Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .success { color: green; }
        .error { color: red; }
        pre { background: #f5f5f5; padding: 10px; }
    </style>
</head>
<body>
    <h1>Database Connection Test</h1>";

echo "<h2>Configuration</h2>";
echo "<p>Host: $db_host</p>";
echo "<p>Database: $db_name</p>";
echo "<p>User: $db_user</p>";
echo "<p>Port: $db_port</p>";

echo "<h2>Testing Connection</h2>";

try {
    $dsn = "mysql:host=$db_host;port=$db_port;dbname=$db_name;charset=utf8mb4";
    $pdo = new PDO($dsn, $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    echo "<p class='success'>✓ Database connection successful!</p>";
    
    // Test if required tables exist
    $required_tables = [
        'outlets', 'users', 'services', 'staff', 'customers', 
        'package_templates', 'customer_packages', 'invoices', 
        'invoice_items', 'service_records', 'vouchers', 
        'staff_attendance', 'payroll_adjustments', 'daily_expenses',
        'outlet_expenses', 'profit_loss', 'user_outlets', 'package_service_records'
    ];
    
    echo "<h2>Checking Required Tables</h2>";
    $missing_tables = [];
    
    foreach ($required_tables as $table) {
        try {
            $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
            $stmt->execute([$table]);
            if ($stmt->rowCount() > 0) {
                echo "<p class='success'>✓ Table '$table' exists</p>";
            } else {
                echo "<p class='error'>✗ Table '$table' is missing</p>";
                $missing_tables[] = $table;
            }
        } catch (Exception $e) {
            echo "<p class='error'>✗ Error checking table '$table': " . $e->getMessage() . "</p>";
            $missing_tables[] = $table;
        }
    }
    
    if (empty($missing_tables)) {
        echo "<p class='success'>✓ All required tables are present!</p>";
    } else {
        echo "<p class='error'>✗ Missing tables: " . implode(', ', $missing_tables) . "</p>";
        echo "<p>You need to import the database schema from api/database/schema.sql</p>";
    }
    
} catch (PDOException $e) {
    echo "<p class='error'>✗ Database connection failed: " . $e->getMessage() . "</p>";
    echo "<h2>Troubleshooting Steps</h2>";
    echo "<ol>";
    echo "<li>Verify database credentials in .env file</li>";
    echo "<li>Check if database server is running</li>";
    echo "<li>Confirm database user has proper permissions</li>";
    echo "<li>Verify database 'ansira_db' exists</li>";
    echo "</ol>";
}

echo "</body></html>";
?>