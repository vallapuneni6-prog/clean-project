<?php
// Debug script to identify server issues
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html>
<html>
<head>
    <title>Debug Information</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .section { margin-bottom: 20px; }
        .success { color: green; }
        .error { color: red; }
        .warning { color: orange; }
        pre { background: #f5f5f5; padding: 10px; }
    </style>
</head>
<body>
    <h1>Server Debug Information</h1>";

// Check PHP version
echo "<div class='section'>";
echo "<h2>PHP Information</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";

// Check required extensions
$required_extensions = ['mysqli', 'json', 'openssl', 'mbstring'];
echo "<p>Required Extensions:</p><ul>";
foreach ($required_extensions as $ext) {
    if (extension_loaded($ext)) {
        echo "<li class='success'>$ext: Loaded</li>";
    } else {
        echo "<li class='error'>$ext: Missing</li>";
    }
}
echo "</ul>";
echo "</div>";

// Check .env file
echo "<div class='section'>";
echo "<h2>Environment File Check</h2>";
if (file_exists('.env')) {
    echo "<p class='success'>.env file found</p>";
    
    // Try to parse .env
    $env_content = file_get_contents('.env');
    if ($env_content !== false) {
        echo "<p class='success'>.env file readable</p>";
        
        // Check for critical variables
        $has_db_config = (strpos($env_content, 'DB_HOST') !== false) && 
                         (strpos($env_content, 'DB_NAME') !== false) &&
                         (strpos($env_content, 'DB_USER') !== false);
                         
        if ($has_db_config) {
            echo "<p class='success'>Database configuration present</p>";
        } else {
            echo "<p class='error'>Database configuration missing</p>";
        }
    } else {
        echo "<p class='error'>.env file not readable</p>";
    }
} else {
    echo "<p class='error'>.env file not found</p>";
}
echo "</div>";

// Check file permissions
echo "<div class='section'>";
echo "<h2>File Permissions</h2>";
$files_to_check = ['.env', 'api', 'dist'];
foreach ($files_to_check as $file) {
    if (file_exists($file)) {
        $perms = fileperms($file);
        $perm_string = substr(sprintf('%o', $perms), -4);
        echo "<p>$file: $perm_string</p>";
    }
}
echo "</div>";

// Check Apache modules
echo "<div class='section'>";
echo "<h2>Apache Modules</h2>";
if (function_exists('apache_get_modules')) {
    $modules = apache_get_modules();
    echo "<p>Available modules: " . implode(', ', array_slice($modules, 0, 10)) . "</p>";
    if (in_array('mod_rewrite', $modules)) {
        echo "<p class='success'>mod_rewrite: Available</p>";
    } else {
        echo "<p class='error'>mod_rewrite: Not available</p>";
    }
} else {
    echo "<p>Cannot check Apache modules</p>";
}
echo "</div>";

echo "</body></html>";
?>